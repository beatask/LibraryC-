﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt
{
    internal class Biblioteka
    {
        List<Ksiazka> listaKsiazek;
        List<Czytelnik> listaCzytelnikow;
        List<Gatunek> listaGatunkow;
        List<Autor> listaAutorow;
        List<Wypozyczenie> listaWypozyczen;

        public void DodajGatunek()
        {

        }
        public void EdytujGatunek()
        {

        }
        public void UsunGatunek()
        {

        }
        public void DodajCzytelnika()
        {

        }
        public void EdytujCzytelnika()
        {

        }
        public void UsunCzytelnika()
        {

        }
        public void DodajKsiazke()
        {

        }
        public void EdytujKsiazke()
        {

        }
        public void UsunKsiazke()
        {

        }
        public void DodajAutora()
        {

        }
        public void EdytujAutora()
        {

        }
        public void UsunAutora()
        {

        }
        public void Wypozycz()
        {

        }
        public void Zwroc()
        {

        }
        public void DostepneKsiazki()
        {

        }
    }
}
