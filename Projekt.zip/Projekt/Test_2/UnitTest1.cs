﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Test_2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
